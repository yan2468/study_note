create
    definer = root@localhost procedure sp_t4(IN str1 varchar(50), IN num2 int)
BEGIN
	SELECT sum(score) 总分 ,avg(score) 平均分  FROM scores where studentno in (SELECT studentno FROM studentinfo WHERE speciality=str1) && courseno=num2;
END;

