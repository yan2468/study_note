create
    definer = root@localhost procedure sp_emp3(OUT nums int)
BEGIN
	SELECT count(*) into nums FROM emp ; -- into为赋值
END;

