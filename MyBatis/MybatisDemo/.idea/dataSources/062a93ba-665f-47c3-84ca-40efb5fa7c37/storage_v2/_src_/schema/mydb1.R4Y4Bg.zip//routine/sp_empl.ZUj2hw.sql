create
    definer = root@localhost procedure sp_empl()
BEGIN
	SELECT emp.*,dname FROM emp,dept WHERE emp.deptno=dept.deptno;
	SELECT * FROM dept;
END;

