create definer = root@localhost view v_kefen as
select `a`.`studentno` AS `studentno`, `a`.`score` AS `score`, `b`.`coursename` AS `coursename`
from `mydb1`.`scores` `a`
         join `mydb1`.`course` `b`
where ((`a`.`courseno` = `b`.`courseno`) and (`a`.`studentno` = 20170101));

