create
    definer = root@localhost procedure sp_t1(IN stuno int)
begin
	select * from scores where studentno=stuno;
end;

