create
    definer = root@localhost procedure sp_t3(IN deno int)
BEGIN
	
	SELECT * FROM emp WHERE empno IN(SELECT mgr 经理 FROM emp WHERE deptno=deno);   	
END;

