create definer = root@localhost view v_stumess as
select `a`.`studentname` AS `studentname`,
       `b`.`studentno`   AS `studentno`,
       `b`.`score`       AS `score`,
       `b`.`coursename`  AS `coursename`
from `mydb1`.`studentinfo` `a`
         join `mydb1`.`v_kefen` `b`
where (`a`.`studentno` = `b`.`studentno`);

