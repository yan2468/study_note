create
    definer = root@localhost procedure sp_t2(IN couno int)
begin
	select sum(score),avg(score) from scores where courseno=couno;
end;

