create definer = root@localhost view v_general as
select `mydb1`.`emp`.`empno`  AS `empno`,
       `mydb1`.`emp`.`ename`  AS `ename`,
       `mydb1`.`emp`.`job`    AS `job`,
       `mydb1`.`emp`.`mgr`    AS `mgr`,
       `mydb1`.`emp`.`deptno` AS `deptno`
from `mydb1`.`emp`;

grant select on table v_general to user_gen;

