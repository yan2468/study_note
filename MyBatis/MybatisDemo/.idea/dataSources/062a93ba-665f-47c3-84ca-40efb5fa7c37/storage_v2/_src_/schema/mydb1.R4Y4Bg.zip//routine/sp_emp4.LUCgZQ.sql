create
    definer = root@localhost procedure sp_emp4(IN dno int, OUT nums int, OUT avgsal double)
begin
	select count(*),avg(sal) into nums,avgsal from emp where deptno=dno;
end;

