create definer = root@localhost view v_scores as
select `mydb1`.`scores`.`studentno`        AS `studentno`,
       `mydb1`.`studentinfo`.`studentname` AS `studentname`,
       `mydb1`.`scores`.`courseno`         AS `courseno`,
       `mydb1`.`course`.`coursename`       AS `coursename`,
       `mydb1`.`scores`.`score`            AS `score`
from `mydb1`.`scores`
         join `mydb1`.`studentinfo`
         join `mydb1`.`course`
where ((`mydb1`.`scores`.`studentno` = `mydb1`.`studentinfo`.`studentno`) and
       (`mydb1`.`scores`.`courseno` = `mydb1`.`course`.`courseno`));

