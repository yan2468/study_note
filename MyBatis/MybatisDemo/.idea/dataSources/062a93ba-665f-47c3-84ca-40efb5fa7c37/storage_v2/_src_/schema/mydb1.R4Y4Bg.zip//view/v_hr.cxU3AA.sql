create definer = root@localhost view v_hr as
select `mydb1`.`emp`.`empno`    AS `empno`,
       `mydb1`.`emp`.`ename`    AS `ename`,
       `mydb1`.`emp`.`job`      AS `job`,
       `mydb1`.`emp`.`mgr`      AS `mgr`,
       `mydb1`.`emp`.`hiredate` AS `hiredate`,
       `mydb1`.`emp`.`sal`      AS `sal`,
       `mydb1`.`emp`.`deptno`   AS `deptno`
from `mydb1`.`emp`;

grant select on table v_hr to user_hr;

